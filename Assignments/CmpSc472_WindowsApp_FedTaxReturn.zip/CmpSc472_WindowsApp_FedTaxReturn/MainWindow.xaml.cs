﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace CmpSc472_WindowsApp_FedTaxReturn
	{
	/// <summary>
	/// Interaction logic for MainWindow.xaml
	/// </summary>
	public partial class MainWindow : Window
		{
		public MainWindow()
			{
			InitializeComponent();
			}

		private void RadioButton_Checked(object sender, RoutedEventArgs e)
			{

			}

        private void TextBox_TextChanged(object sender, TextChangedEventArgs e)
        {

        }

        private void firstName_txt_TextChanged(object sender, TextChangedEventArgs e)
        {

        }

		private void incomeTaxWithheld_cbo_SelectionChanged(object sender, SelectionChangedEventArgs e)
		{

		}

        private void clearFields_btn_Click(object sender, RoutedEventArgs e)
        {
			firstName_txt.Clear();
			lastName_txt.Clear();
			SSN_txt.Clear();
			grossIncome_txt.Clear();
			taxesPaid_txt.Clear();
			charitableDonations_txt.Clear();
			mortgageInterest_txt.Clear();
			noOfDependents_txt.Clear();
		}

        private void exit_btn_Click(object sender, RoutedEventArgs e)
        {
			MessageBoxResult result = MessageBox.Show("Are You Sure?", "Exit", MessageBoxButton.YesNo);
			if (result == MessageBoxResult.Yes)
			{
				Application.Current.Shutdown();
			}
        }

        private void calculateTaxes_btn_Click(object sender, RoutedEventArgs e)
        {
			decimal grossIncome = decimal.Parse(grossIncome_txt.Text);
			decimal charitableDeductions = decimal.Parse(charitableDonations_txt.Text);
			decimal mortgageInterest = decimal.Parse(mortgageInterest_txt.Text);
			decimal taxesPaid = decimal.Parse(taxesPaid_txt.Text);
			int dependents = int.Parse(noOfDependents_txt.Text);

			// calculate adjusted gross income
			decimal AGI = grossIncome - charitableDeductions - mortgageInterest - (dependents * 5000);

			// determine tax rate based on filing status
			decimal taxRate = 0m;
			if (single_rad.IsChecked == true)
			{
				taxRate = 0.25m;
			}
			else if (marriedSeparately_rad.IsChecked == true) 
			{
				taxRate = 0.22m;
			}
            else if (marriedJointly_rad.IsChecked == true)
            {
                taxRate = 0.18m;
            }
            else if (headOfHousehold_rad.IsChecked == true)
            {
                taxRate = 0.20m;
            }

			decimal netIncome = AGI - (AGI * taxRate);
			decimal difference = taxesPaid - netIncome;

			result_txt.Text = difference >= 0 ? "REFUND" : "OWE";
			amount_txt.Text = Math.Abs(difference).ToString("C");

        }
    }
}
