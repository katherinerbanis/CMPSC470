#include <stdio.h>
#include <stdlib.h>
#include "data_structure.h"

int main_write_data() {
    FILE *file;
    char filePath[] = "C:\\Temp\\CmpSc472_BinaryFile_Data.bin"; // File path for bin file

    file = fopen(filePath, "wb");
    if (file == NULL) {
        fprintf(stderr, "Error opening file for writing.\n");
        return 1;
    }

    int exampleData[] = {10, 20, 30, 40, 50};

    // Write 5 records of data to the bin file
    for (int i = 0; i < 5; i++) {
        DataStructure data;
        data.id = i + 1;
        data.value = 10 * data.id;

        // Write the data
        fwrite(&data, sizeof(DataStructure), 1, file);
    }

    // Close the file
    fclose(file);

    printf("Data has been successfully written to the binary file.\n");

    return 0;
}