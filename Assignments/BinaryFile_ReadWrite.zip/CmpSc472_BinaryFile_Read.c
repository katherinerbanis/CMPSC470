// Katherine Banis
// CMPSC 472
// Lab: Read and Write Binary Files
// The write program creates a data file and writes 5 records of data to the file.
// The read program opens the data file and reads the 5 records of data.
// My partner was Gwen Hu. I did the read file, she did the write file and .h file.

#include <stdio.h>
#include <stdlib.h>
#include "data_structure.h"

char filepath[] = "C:\\Temp\\CmpSc472_BinaryFile_Data.bin"; 


int main_read_data() {
    FILE *file;
    DataStructure record;
    int recordsRead = 0;

    // open binary file for reading
    file = fopen(filepath, "rb");
    if (file == NULL) {
        fprintf(stderr, "Cannot open file %s\n", filepath);
        return 1;
    }

    // read records from file
    printf("Reading records from %s...\n", filepath);
    while(fread(&record, sizeof(DataStructure), 1, file)) {
        printf("Record %d: ID=%d, Value=%d\n",
               ++recordsRead, record.id, record.value);
    }

    if(recordsRead == 0) {
        printf("No records found.\n");
    }
    else {
        printf("Total records read: %d\n", recordsRead);
    }

    fclose(file);

    return 0;
}

int main() {
    return main_read_data();
}