#ifndef DATA_STRUCTURE_H
#define DATA_STRUCTURE_H

typedef struct {
    int id;
    int value;
} DataStructure;

extern char filepath[]; // File path for the binary file

#endif /* DATA_STRUCTURE_H */